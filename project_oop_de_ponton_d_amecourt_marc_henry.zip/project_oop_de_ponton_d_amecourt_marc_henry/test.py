import unittest
from project_oop import Calculator

class TestCalculator(unittest.TestCase):
    def setUp(self):
        self.calculator = Calculator()

    def test_addition(self):
        result = self.calculator.evaluate_expression("2 + 3")
        self.assertEqual(result, 5)

    def test_subtraction(self):
        result = self.calculator.evaluate_expression("5 - 3")
        self.assertEqual(result, 2)

    def test_multiplication(self):
        result = self.calculator.evaluate_expression("2 * 3")
        self.assertEqual(result, 6)

    def test_division(self):
        result = self.calculator.evaluate_expression("6 / 2")
        self.assertEqual(result, 3)

    def test_complex_expression(self):
        result = self.calculator.evaluate_expression("(3 + 4) * 2 - 5")
        self.assertEqual(result, 9)

if __name__ == "__main__":
    unittest.main()
    
    
    
    
